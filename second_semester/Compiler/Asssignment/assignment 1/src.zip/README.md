# compile assignment

### Parsing part:

    make parse
    ./parse < test.t > answer.txt
    bat answer.txt

### lex part:

    make tlex
    ./tlex < test.t > answer.txt
    bat answer.txt
